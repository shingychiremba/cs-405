// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

/// Created a class for custom exception occurrance //
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom exception occurred";
    }
};




bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception - DONE
    //
    throw std::logic_error("Standard exception occurred"); //standard exception is thrown.

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    //                      
    //          *********  DONE DONE *********    //
    // 
    try                                 // wrap the call with a try-catch block
    {
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& e)     // catches the exception.    
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    try
    {

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    //
        // ************ DONE **********

        throw CustomException();        // throws the custom exception
    }
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught: " << e.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    //
    //      *********** DONE ***************
    if (den == 0)
    {
        throw std::runtime_error("Divide by zero error occurred"); // throws exception for divide by 0 errors
    }

    return (num / den);
}

void do_division() noexcept
{
    //
    try
    {
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    // 
        // ****** DONE *********

    float numerator = 10.0f;
    float denominator = 0;

    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    // exception handler to capture ONLY the exception thrown by divide
    catch (const std::exception& e)
{
    std::cerr << "Exception caught: " << e.what() << std::endl;
}
}

int main()
{
    std::cout << "Exceptions Tests! - [BEGIN]....." << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    //
    //      ******** DONE ********
    // 
    
    // try-catch block wrap call in main function 
    try
    {
        do_division();
        do_custom_application_logic();
    }
    
    // Exception handlers in the order assigned // 
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught in main: " << e.what() << std::endl;  // custom exception
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught in main: " << e.what() << std::endl;     // standard exception
    }
    catch (...)
    {
        std::cerr << "Unhandled exception caught in main." << std::endl;        // uncaught exceptions
    }
        std::cout << "Exceptions Tests! - [END]" << std::endl;
    
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu