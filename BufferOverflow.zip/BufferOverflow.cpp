// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <string>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    //TODO - DONE//

    const std::string account_number = "CharlieBrown42";
    std::string user_input;
    std::cout << "Enter a value: ";
    std::getline(std::cin, user_input); // change code line to consider # of characters.

    // Check the length of the input
    if (user_input.length() > 20) {
        std::cout << "Error: Input too long." << std::endl;
        return 1;
    }

    // Add a null terminator at the end of the input
    user_input += '\0';

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu